#include "Card.h"


Card::Card(string name, double balance, bool iscredit)
{
	this->name = name;
	this->balance = balance;
	this->iscredit = iscredit;
}
string Card::getName() {
	return name;
}
int Card::getBalance() {
	return balance;
}
bool Card::isCredit() {
	return iscredit;
}
void Card::updateBalance(int balance) {
	this->balance += balance;
}

string Card::print() {
	return name + "\n" + to_string(balance) + "\n" + (iscredit ? "Credit" : "Debit");
}