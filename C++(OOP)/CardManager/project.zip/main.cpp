#include <conio.h>
#include <iostream>
#include <Money.h>
int main()
{
	Money money;
	int choose = 0;
		system("cls");
		cout << "1.Manage your cards" << endl;
		cout << "2.Manage your payments" << endl;
		cout << "3.Exit" << endl;
		cin >> choose;
		switch (choose) 
		{
			case 1:
{
				int choose = 0;
		system("cls");
		cout << "1.All cards" << endl;
		cout << "2.Add money" << endl;
		cout << "3.Add card" << endl;
		cin >> choose;
		switch (choose) 
		{
			case 1:
			{
				money.getAllCards();
				_getch();
				break;
			}
			case 2:
			{
				int index;
				double money;
				money.getAllCards();
				cout << "Enter card number for adding money : ";
				cin >> index;
				cout << "Enter money amount : ";
				cin >> money;
				store.updateBalance(index, money);
				break;
			}
			case 3:
			{
				string name;
				double balance;
				cout << "Enter card name" << endl;
				cin >> name;
				cout << "Enter card balance" << endl;
				cin >> balance;
				cout << "1.Debit" << endl;
				cout << "2.Credit" << endl;
				int type;
				cin >> type;
				Card card(name, balance, type == 1 ? false : true);
				money.addCard(card);
				break;
			}
			
		}
	}
				break;
}
			case 2:
{   
	int choose = 0;

		system("cls");
		cout << "1.All Payments" << endl;
		cout << "2.Make payment" << endl;
		cout << "3.Payment by day" << endl;
		cout << "4.Payment by week" << endl;
		cout << "5.Payment by month" << endl;
		cout << "6.TOP-3 Payment by week" << endl;
		cout << "7.TOP-3 Payment by month" << endl;
		cout << "8.TOP-3 Category by week" << endl;
		cout << "9.TOP-3 Category by month" << endl;
		
		cin >> choose;

		switch (choose) 
		{
			case 1:
			{
				money.getAllPayments();
				_getch();
				break;
			}
			case 2:
			{	
				string name;
				int day;
				int month;
				int year;
				string category;
				int cost;
				cout << "Enter payment name" << endl;
				cin >> name;
				
				cout << "Enter day" << endl;
				cin >> day;
				cout << "Enter month" << endl;
				cin >> month;
				cout << "Enter year" << endl;
				cin >> year;
				cout << "Select category:" << endl;
				cout << "1.Product" << endl;
				cout << "2.Internet" << endl;
				cout << "3.Comunality" << endl;
				cout << "4.Study" << endl;
				cout << "5.Other" << endl;
				
				int cat = 0;
				cin >> cat;

				switch (cat) 
				{
					case 1: {
						category = "Product";
						break;
					}
					case 2: {
						category = "Internet";
						break;
					}
					case 3: {
						category = "Comunality";
						break;
					}
					case 4: {
						category = "Study";
						break;
					}
					case 5: {
						category = "Other";
						break;
					}
				}

				cout << "Enter cost" << endl;
				cin >> cost;
				Payment payment(name, day, month, year, category, cost);
				int index;
				do {
					system("cls");
					money.getAllCards();
					cout << "Enter card number for making payment:";
					cin >> index;
				} while (!money.makePayment(payment, index));
				break;
			}
			case 3:
			{
				system("cls");
				int day;
				int month;
				int year;
				
				cout << "Enter day" << endl;
				cin >> day;
				cout << "Enter month" << endl;
				cin >> month;
				cout << "Enter year" << endl;
				cin >> year;
				
				store.getAllPaymentsByDay(day, month, year);
				_getch();

				break;
			}
			case 4:
			{	
				system("cls");
				int week;
				int month;
				int year;

				cout << "Enter week" << endl;
				cin >> week;
				cout << "Enter month" << endl;
				cin >> month;
				cout << "Enter year" << endl;
				cin >> year;

				store.getAllPaymentsByWeek(week, month, year);
				_getch();

				break;
			}
			case 5:
			{	system("cls");
				
				int month;
				int year;

				cout << "Enter month" << endl;
				cin >> month;
				cout << "Enter year" << endl;
				cin >> year;

				store.getAllPaymentsByMonth(month, year);
				_getch();
				break;
			}
			
			case 6:
			{
				system("cls");
				int week;
				int month;
				int year;

				cout << "Enter week" << endl;
				cin >> week;
				cout << "Enter month" << endl;
				cin >> month;
				cout << "Enter year" << endl;
				cin >> year;

				store.getTop3PaymentByWeek(week, month, year);
				_getch();

				break;
			}
			case 7:
			{
				system("cls");
				int month;
				int year;

				cout << "Enter month" << endl;
				cin >> month;
				cout << "Enter year" << endl;
				cin >> year;

				store.getTop3PaymentByMonth(month, year);
				_getch();

				break;
			}
			case 8:
			{
				system("cls");
				int week;
				int month;
				int year;

				cout << "Enter week" << endl;
				cin >> week;
				cout << "Enter month" << endl;
				cin >> month;
				cout << "Enter year" << endl;
				cin >> year;

				store.getTop3CategoryByWeek(week, month, year);
				_getch();
				break;
			}
			case 9:
			{
				system("cls");

				int month;
				int year;

				cout << "Enter month" << endl;
				cin >> month;
				cout << "Enter year" << endl;
				cin >> year;

				store.getTop3CategoryByMonth(month, year);
				_getch();
				break;
			}
		}
	}

	break;
}
			case 3:
{
	           system("cls");
				break;
}
		
	
	

