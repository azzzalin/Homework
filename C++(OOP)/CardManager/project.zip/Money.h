#pragma once
#include <vector>
#include <iostream>
#include <string>
#include <fstream>
#include "Card.h"
#include "Data.h"
#include <conio.h>
#include <map>
#include <algorithm>


class Money
{
private:
	vector<Card> cards;
	vector<Payment> payments;
public:
	Store();
	
	void load();
	void save();
	
	vector<Card> getAllCards();
	vector<Payment> getAllPayments();
	
	void addCard(Card card);
	void updateBalance(int index, int money);
    bool makePayment(Payment payment, int index);
	void getAllPaymentsByDay(int day, int month,int year);
	void getAllPaymentsByWeek(int week, int month, int year);
	void getAllPaymentsByMonth(int month, int year);
	void getTop3PaymentByWeek(int week, int month, int year);
	void getTop3PaymentByMonth(int month, int year);
	void getTop3CategoryByWeek(int week, int month, int year);
	void getTop3CategoryByMonth(int month, int year);

};

